#define UNICODE
#define _UNICODE
#include <windows.h>
#include <string>
#include <vector>

int WINAPI wWinMain(HINSTANCE,HINSTANCE,PWSTR,int) {
    std::vector<wchar_t> buffer(32768);
    DWORD count=GetModuleFileNameW(nullptr,buffer.data(),static_cast<DWORD>(buffer.size()));
    if(!count || count>=buffer.size()) return 1;
    std::wstring module(buffer.data(),count);
    std::wstring root=module.substr(0,module.find_last_of(L"\\/"));
    std::wstring python=root+L"\\runtime\\pythonw.exe";
    std::wstring ready=root+L"\\runtime\\READY.json";
    bool prepared=GetFileAttributesW(ready.c_str())!=INVALID_FILE_ATTRIBUTES && GetFileAttributesW(python.c_str())!=INVALID_FILE_ATTRIBUTES;
    std::wstring application,command;
    if(prepared) {
        application=python;
        command=L"\""+python+L"\" -I -B -X utf8 \""+root+L"\\launch.py\" --home \""+root+L"\"";
    } else {
        std::vector<wchar_t> system(32768);GetSystemDirectoryW(system.data(),static_cast<UINT>(system.size()));
        application=std::wstring(system.data())+L"\\WindowsPowerShell\\v1.0\\powershell.exe";
        command=L"\""+application+L"\" -NoProfile -ExecutionPolicy Bypass -File \""+root+L"\\Start.ps1\"";
    }
    std::vector<wchar_t> arguments(command.begin(),command.end());arguments.push_back(0);
    STARTUPINFOW startup{};startup.cb=sizeof(startup);PROCESS_INFORMATION process{};
    if(!CreateProcessW(application.c_str(),arguments.data(),nullptr,nullptr,FALSE,0,nullptr,root.c_str(),&startup,&process)) {
        MessageBoxW(nullptr,L"Не удалось запустить VolleyScope. Распакуйте весь ZIP в обычную папку и запустите снова.",L"VolleyScope",MB_OK|MB_ICONERROR);
        return 1;
    }
    CloseHandle(process.hThread);WaitForSingleObject(process.hProcess,INFINITE);
    DWORD exitCode=0;GetExitCodeProcess(process.hProcess,&exitCode);CloseHandle(process.hProcess);
    return static_cast<int>(exitCode);
}
