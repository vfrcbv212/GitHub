"""VolleyScope: a new implementation, independent of previous projects."""
__version__ = "0.1.0"
