"""Cache small Cyrillic label sprites instead of converting whole video frames."""
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image,ImageDraw,ImageFont


@lru_cache(maxsize=512)
def sprite(text,color,size):
    from matplotlib import get_data_path
    font=ImageFont.truetype(str(Path(get_data_path())/'fonts/ttf/DejaVuSans.ttf'),size)
    probe=ImageDraw.Draw(Image.new('RGB',(1,1)));box=probe.textbbox((0,0),text,font=font)
    image=Image.new('RGBA',(box[2]-box[0]+8,box[3]-box[1]+6),(18,27,35,200))
    ImageDraw.Draw(image).text((4-box[0],3-box[1]),text,font=font,fill=tuple(reversed(color))+(255,))
    array=np.array(image);return array[:,:,:3][:,:,::-1].copy(),array[:,:,3:4].astype(np.float32)/255


def label(image,text,x,y,color,size=18):
    rgb,alpha=sprite(text,tuple(color),size);h,w=image.shape[:2];ph,pw=rgb.shape[:2]
    x=max(0,min(w-pw,int(x)));y=max(0,min(h-ph,int(y)));right=min(w,x+pw);bottom=min(h,y+ph)
    if right<=x or bottom<=y:return
    a=alpha[:bottom-y,:right-x];patch=rgb[:bottom-y,:right-x]
    image[y:bottom,x:right]=(a*patch+(1-a)*image[y:bottom,x:right]).astype(np.uint8)
