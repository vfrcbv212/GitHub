"""Reusable measured poses, independent of manual scene labels and rendering."""
import hashlib
import json
from pathlib import Path

from .session import atomic_json


def pose_key(session,model_root):
    manifest=json.loads((Path(model_root)/'manifest.json').read_text())
    contract={'source':session.data['sha256'],'model':manifest['pose']['sha256'],
              'pose_size':session.data['settings'].get('pose_size',960),'confidence':.3,'iou':.5,
              'pixel_geometry':session.data['metadata'],'contract':1}
    return hashlib.sha256(json.dumps(contract,sort_keys=True).encode()).hexdigest()[:24],contract


class PoseCacheWriter:
    def __init__(self,folder,key,contract):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True);self.key=key;self.contract=contract
        self.path=self.folder/(key+'.jsonl');self.partial=self.path.with_suffix('.partial.jsonl')
        self.stream=self.partial.open('wb');self.digest=hashlib.sha256();self.count=0

    def add(self,index,timestamp,people):
        raw=json.dumps({'index':index,'time':timestamp,'people':people},allow_nan=False,separators=(',',':')).encode()+b'\n'
        self.stream.write(raw);self.digest.update(raw);self.count+=1

    def close(self,complete):
        self.stream.close()
        if complete:
            self.partial.replace(self.path);atomic_json(self.folder/(self.key+'.json'),
                {'contract':self.contract,'frames':self.count,'sha256':self.digest.hexdigest(),'complete':True})


class PoseCacheReader:
    def __init__(self,folder,key,contract):
        self.path=Path(folder)/(key+'.jsonl');meta=json.loads((Path(folder)/(key+'.json')).read_text())
        if not meta.get('complete') or meta['contract']!=contract:raise ValueError('Pose cache belongs to different inputs')
        digest=hashlib.sha256()
        with self.path.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
        if digest.hexdigest()!=meta['sha256']:raise ValueError('Pose cache is corrupted')
        self.stream=self.path.open('r',encoding='utf-8');self.expected=meta['frames'];self.count=0

    def read(self,index,timestamp):
        line=self.stream.readline()
        if not line:raise ValueError('Pose cache ended early')
        row=json.loads(line)
        if row['index']!=index or abs(row['time']-timestamp)>1e-5:raise ValueError('Pose cache timestamp mismatch')
        self.count+=1;return row['people']

    def close(self):self.stream.close()
