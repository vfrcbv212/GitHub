"""Local learning from reviewed scenes, guarded by photographic registration."""
import json
from pathlib import Path

import cv2
import numpy as np


STATIC={'court','center','attack_a','attack_b','net_top','net_bottom','antenna_a','antenna_b'}


def registered_geometry(reference,current,geometry):
    """Transfer reviewed points only for a strongly matching fixed camera view."""
    rh,rw=reference.shape[:2];h,w=current.shape[:2]
    if abs(w/h-rw/rh)>.03:return None
    resized=cv2.resize(reference,(w,h));scale=min(1,960/w)
    a=cv2.resize(cv2.cvtColor(resized,cv2.COLOR_BGR2GRAY),None,fx=scale,fy=scale)
    b=cv2.resize(cv2.cvtColor(current,cv2.COLOR_BGR2GRAY),None,fx=scale,fy=scale)
    detector=cv2.ORB_create(nfeatures=1800);ka,da=detector.detectAndCompute(a,None);kb,db=detector.detectAndCompute(b,None)
    if da is None or db is None:return None
    matches=cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(da,db,k=2)
    good=[pair[0] for pair in matches if len(pair)==2 and pair[0].distance<.7*pair[1].distance]
    if len(good)<80:return None
    p=np.array([ka[m.queryIdx].pt for m in good],np.float32);q=np.array([kb[m.trainIdx].pt for m in good],np.float32)
    matrix,mask=cv2.findHomography(p,q,cv2.RANSAC,2)
    if matrix is None or mask is None:return None
    inliers=mask.ravel().astype(bool)
    if inliers.sum()<70 or inliers.mean()<.8:return None
    extent=np.ptp(p[inliers],axis=0)
    if extent[0]<a.shape[1]*.45 or extent[1]<a.shape[0]*.25:return None
    corners=np.array([[[0,0],[a.shape[1],0],[a.shape[1],a.shape[0]],[0,a.shape[0]]]],np.float32)
    moved=cv2.perspectiveTransform(corners,matrix)[0]
    if np.linalg.norm(moved-corners[0],axis=1).max()>a.shape[1]*.025:return None
    transformed=cv2.perspectiveTransform(p[None],matrix)[0]
    error=float(np.median(np.linalg.norm(transformed[inliers]-q[inliers],axis=1)))
    if error>1.2:return None
    result={}
    for key,points in geometry.items():
        if key not in STATIC or not points:continue
        scaled=np.asarray(points,np.float32)*[w/rw*scale,h/rh*scale]
        mapped=cv2.perspectiveTransform(scaled[None].astype(np.float32),matrix)[0]/scale
        if np.any(mapped[:,0]<0) or np.any(mapped[:,0]>=w) or np.any(mapped[:,1]<0) or np.any(mapped[:,1]>=h):continue
        result[key]=mapped.tolist()
    return {'geometry':result,'inliers':int(inliers.sum()),'median_error_small_px':error,
            'evidence':'registered_reviewed_scene','human_confirmed_this_video':False} if result else None


def recall_scene(sessions_root,current,exclude_session=None):
    from .session import Session
    paths=sorted(Path(sessions_root).glob('*/session.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    for path in paths[:30]:
        if exclude_session and path.parent.resolve()==Path(exclude_session).resolve():continue
        try:
            session=Session(path.parent);geometry=session.geometry()
            if not any(key in STATIC for key in geometry):continue
            for row in reversed(session.data['corrections'][-3:]):
                image_path=session.root/row['image'];image=cv2.imdecode(np.fromfile(image_path,np.uint8),cv2.IMREAD_COLOR)
                if image is None:continue
                result=registered_geometry(image,current,geometry)
                if result:
                    result['source_session']=session.data['id'];result['source_image']=row['image'];return result
        except (OSError,ValueError,KeyError,json.JSONDecodeError,cv2.error):continue
    return None
