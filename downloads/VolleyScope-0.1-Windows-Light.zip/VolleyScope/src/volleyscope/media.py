"""Ordered video I/O, bounded batches and exact source timestamps."""
from dataclasses import dataclass
from fractions import Fraction
import hashlib
from pathlib import Path

import av
import cv2


@dataclass
class Frame:
    index:int
    time:float
    image:object


def fingerprint(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def metadata(path):
    with av.open(str(path)) as container:
        stream=container.streams.video[0]
        duration=float(stream.duration*stream.time_base) if stream.duration is not None else (container.duration or 0)/av.time_base
        fps=float(stream.average_rate or 30)
        return {'width':stream.width,'height':stream.height,'fps':fps,'duration':duration,
                'frames':stream.frames,'rotation':int(stream.metadata.get('rotate',0))%360}


def decode(path,start=0,end=None):
    with av.open(str(path)) as container:
        stream=container.streams.video[0];stream.thread_type='AUTO';stream.codec_context.thread_count=2
        origin=float((stream.start_time or 0)*stream.time_base);rotation=int(stream.metadata.get('rotate',0))%360
        if start>0:container.seek(int((start+origin)/stream.time_base),stream=stream,backward=True)
        for index,frame in enumerate(container.decode(stream)):
            if frame.pts is None:raise ValueError('Кадр без временной метки')
            timestamp=float(frame.pts*frame.time_base)-origin
            if timestamp<start-1e-6:continue
            if end is not None and timestamp>=end:break
            bgr=frame.to_ndarray(format='bgr24')
            if rotation in (90,180,270):bgr=cv2.rotate(bgr,{90:cv2.ROTATE_90_CLOCKWISE,180:cv2.ROTATE_180,270:cv2.ROTATE_90_COUNTERCLOCKWISE}[rotation])
            yield Frame(index,timestamp,bgr)


def at(path,timestamp):
    rows=decode(path,start=timestamp)
    try:return next(rows)
    finally:rows.close()


def batches(rows,size=9):
    batch=[]
    try:
        for row in rows:
            batch.append(row)
            if len(batch)==size:yield batch;batch=[]
        if batch:yield batch
    finally:
        close=getattr(rows,'close',None)
        if close:close()


class VideoWriter:
    def __init__(self,path,width,height,fps):
        self.path=Path(path);self.partial=self.path.with_name(self.path.stem+'.partial.mp4')
        self.container=av.open(str(self.partial),'w')
        self.stream=self.container.add_stream('libx264',rate=Fraction(fps).limit_denominator(100000))
        self.stream.width=width;self.stream.height=height;self.stream.pix_fmt='yuv420p'
        self.stream.options={'crf':'19','preset':'veryfast'};self.stream.time_base=Fraction(1,1000000)
        self.first=None;self.frames=0;self.last_pts=-1

    def add(self,bgr,timestamp):
        if self.first is None:self.first=timestamp
        pts=round((timestamp-self.first)*1000000)
        if pts<=self.last_pts:raise ValueError('Нарушен порядок временных меток')
        frame=av.VideoFrame.from_ndarray(bgr,format='bgr24');frame.pts=pts;frame.time_base=Fraction(1,1000000)
        for packet in self.stream.encode(frame):self.container.mux(packet)
        self.last_pts=pts;self.frames+=1

    def close(self,complete=True):
        try:
            for packet in self.stream.encode():self.container.mux(packet)
        finally:self.container.close()
        if complete:self.partial.replace(self.path)
        return self.path if complete else self.partial


def preserve_audio(source,rendered):
    """Remux original audio without re-encoding; preserve the completed video."""
    rendered=Path(rendered);temporary=rendered.with_name(rendered.stem+'.audio.partial.mp4')
    try:
        with av.open(str(source)) as original,av.open(str(rendered)) as video:
            if not original.streams.audio:return False
            audio_stream=original.streams.audio[0];video_stream=video.streams.video[0]
            origin=float((original.streams.video[0].start_time or 0)*original.streams.video[0].time_base)
            offset=round(origin/audio_stream.time_base)
            with av.open(str(temporary),'w') as output:
                out_video=output.add_stream_from_template(video_stream);out_audio=output.add_stream_from_template(audio_stream)
                def packets(container,stream,target,shift=0):
                    for packet in container.demux(stream):
                        if packet.dts is None:continue
                        if packet.pts is not None:packet.pts-=shift
                        packet.dts-=shift;timestamp=float(packet.dts*packet.time_base);packet.stream=target
                        yield timestamp,packet
                iterators=[iter(packets(video,video_stream,out_video)),iter(packets(original,audio_stream,out_audio,offset))]
                heads=[next(it,None) for it in iterators]
                while any(row is not None for row in heads):
                    index=min((i for i,row in enumerate(heads) if row is not None),key=lambda i:heads[i][0])
                    output.mux(heads[index][1]);heads[index]=next(iterators[index],None)
        temporary.replace(rendered);return True
    finally:temporary.unlink(missing_ok=True)
