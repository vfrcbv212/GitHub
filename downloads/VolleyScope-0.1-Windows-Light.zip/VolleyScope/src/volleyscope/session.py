import copy
from dataclasses import dataclass
import json
from pathlib import Path
import uuid
import numpy as np

import cv2

from .media import at,fingerprint,metadata

TOOLS={
    'court':('Видимый контур площадки','polygon',(220,50,210)),
    'center':('Центральная линия','line',(255,140,30)),
    'attack_a':('Три метра — сторона А','line',(40,50,240)),
    'attack_b':('Три метра — сторона Б','line',(40,50,240)),
    'net_top':('Верх сетки','line',(40,220,240)),
    'net_bottom':('Низ сетки','line',(40,220,240)),
    'antenna_a':('Левая антенна: низ → верх','segment',(80,240,100)),
    'antenna_b':('Правая антенна: низ → верх','segment',(80,240,100)),
    'referee':('Судья','box',(80,80,255)),
    'team_a':('Игроки команды А','points',(255,180,80)),
    'team_b':('Игроки команды Б','points',(80,100,255)),
    'ball':('Мяч: центр → край','circle',(80,255,100)),
}


def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.partial')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');temporary.replace(path)


class Session:
    def __init__(self,root,video=None):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self.path=self.root/'session.json'
        if self.path.exists():
            self.data=json.loads(self.path.read_text(encoding='utf-8'))
            if video and str(Path(video).resolve())!=self.data['video']:
                if fingerprint(video)!=self.data['sha256']:raise ValueError('В этой папке другая запись')
                self.data['video']=str(Path(video).resolve());self.save()
        else:
            if not video:raise ValueError('Выберите видео')
            self.data={'schema':1,'id':uuid.uuid4().hex,'video':str(Path(video).resolve()),'sha256':fingerprint(video),
                       'metadata':metadata(video),'corrections':[],'settings':{'pose_size':960}}
            self.save()

    @property
    def video(self):return Path(self.data['video'])

    def save(self):atomic_json(self.path,self.data)

    def correct(self,frame,entries):
        h,w=frame.image.shape[:2]
        for name,points in entries.items():
            if name not in TOOLS:raise ValueError('Неизвестный элемент')
            if not points:continue
            kind=TOOLS[name][1];minimum=3 if kind=='polygon' else 1 if kind=='points' else 2
            if len(points)<minimum or (kind in ('segment','box','circle') and len(points)!=2):raise ValueError('Недостаточно точек: '+TOOLS[name][0])
            for x,y in points:
                if not (0<=x<w and 0<=y<h):raise ValueError('Точка вне кадра')
            if kind=='polygon' and abs(cv2.contourArea(np.array(points,dtype='float32')))<4:raise ValueError('Контур вырожден')
        folder=self.root/'reviewed';folder.mkdir(exist_ok=True);image=folder/f'{frame.time:.6f}.jpg'
        ok,encoded=cv2.imencode('.jpg',frame.image,[cv2.IMWRITE_JPEG_QUALITY,95])
        if not ok:raise ValueError('Не удалось сохранить кадр')
        encoded.tofile(image)
        self.data['revision']=self.data.get('revision',0)+1
        row={'time':frame.time,'image':str(image.relative_to(self.root)),'size':[w,h],'revision':self.data['revision'],
             'entries':copy.deepcopy(entries),'reviewed_by':'user','source_group':self.data['sha256']}
        self.data['corrections']=[r for r in self.data['corrections'] if abs(r['time']-frame.time)>.001]+[row]
        self.data['corrections'].sort(key=lambda r:r['time']);self.save();return row

    def geometry(self,include_empty=False):
        result={}
        # Static camera: latest explicit correction of an element wins. Moving
        # ball/person points retain their exact frame time and never become ROIs.
        for row in sorted(self.data['corrections'],key=lambda r:r.get('revision',0)):
            for name,points in row['entries'].items():
                if name not in ('ball','team_a','team_b'):
                    if points:result[name]=points
                    elif include_empty:result[name]=[]
                    else:result.pop(name,None)
        return result


def select_ten(path,count=10,seed=7,cancel=lambda:False):
    """Stratified temporal sample; choose sharpest of three candidates per bin."""
    import numpy as np
    meta=metadata(path);duration=meta['duration'];rng=np.random.default_rng(seed);selected=[]
    if duration<=0:raise ValueError('Не удалось определить длительность')
    for i in range(count):
        if cancel():raise InterruptedError('Выбор кадров отменён')
        lower=duration*i/count;upper=duration*(i+1)/count
        candidates=[]
        for timestamp in rng.uniform(lower,max(lower,upper-.02),3):
            try:frame=at(path,float(timestamp))
            except StopIteration:continue
            small=cv2.resize(frame.image,(320,180));sharp=float(cv2.Laplacian(cv2.cvtColor(small,cv2.COLOR_BGR2GRAY),cv2.CV_64F).var())
            candidates.append((sharp,frame))
        if candidates:selected.append(max(candidates,key=lambda row:row[0])[1])
    return selected
