"""Bounded ordered inference, preview and full-frame video export."""
import json
from pathlib import Path
import queue
import threading
import time

from .inference import NeuralModels
from .media import batches,decode,VideoWriter,fingerprint,preserve_audio
from .render import draw
from .scene import propose_scene,court_outline
from .session import atomic_json
from .tracking import PeopleTracker,BallTracker


class AnalysisEngine:
    def __init__(self,session,model_root,layers=None,device='auto',model_factory=NeuralModels):
        self.session=session;self.model_root=Path(model_root);self.layers=layers
        self.device=device;self.model_factory=model_factory;self.stop=threading.Event();self.paused=threading.Event()
        self.packets=queue.Queue(maxsize=3);self.error=None;self.result=None;self.thread=None

    def start(self):
        if self.thread and self.thread.is_alive():raise ValueError('Анализ уже идёт')
        self.thread=threading.Thread(target=self.run,name='volleyscope-analysis',daemon=True);self.thread.start()

    def emit(self,packet):
        while not self.stop.is_set():
            try:self.packets.put(packet,timeout=.1);return True
            except queue.Full:continue
        return False

    def run(self):
        writer=None;rows=None;log=None;pose_reader=None;pose_writer=None;started=time.perf_counter();complete=False
        record={'status':'running','frames':0,'dropped_frames':0,'device':None,'timings':{},
            'semantic_scene_automatic_validated':False,'audio_preserved':False}
        target=self.session.root/'annotated.mp4';geometry=self.session.geometry();proposals=[]
        try:
            if fingerprint(self.session.video)!=self.session.data['sha256']:raise ValueError('Исходное видео изменилось')
            options={'pose_size':self.session.data['settings'].get('pose_size',960)}
            if getattr(self.model_factory,'supports_pose_cache',False):
                from .cache import pose_key,PoseCacheReader,PoseCacheWriter
                key,contract=pose_key(self.session,self.model_root)
                try:pose_reader=PoseCacheReader(self.session.root/'pose-cache',key,contract)
                except (FileNotFoundError,ValueError,json.JSONDecodeError):pose_writer=PoseCacheWriter(self.session.root/'pose-cache',key,contract)
                options['load_pose']=pose_reader is None
            model=self.model_factory(self.model_root,self.device,**options);record['device']=model.device
            record['pose_cache_used']=pose_reader is not None;record['ball_backend']='ONNX CPU'
            record['device_warning']=getattr(model,'warning',None)
            people_tracker=PeopleTracker(geometry,self.session.data['corrections']);ball_tracker=BallTracker(self.session.data['corrections'])
            meta=self.session.data['metadata'];rows=batches(decode(self.session.video),size=5)
            log=(self.session.root/'observations.partial.jsonl').open('w',encoding='utf-8')
            for frames in rows:
                while self.paused.is_set() and not self.stop.wait(.1):pass
                if self.stop.is_set():break
                if writer is None:
                    h,w=frames[0].image.shape[:2];writer=VideoWriter(target,w,h,meta['fps'])
                    from .memory import recall_scene
                    remembered=recall_scene(self.model_root.parent/'sessions',frames[0].image,self.session.root)
                    if remembered:
                        blocked={name for name,points in self.session.geometry(include_empty=True).items() if not points}
                        transferred={name:points for name,points in remembered['geometry'].items() if name not in blocked}
                        geometry=transferred|geometry;record['scene_memory']=remembered
                    box=None
                    try:
                        from .learning import CourtProposer
                        box=CourtProposer(self.model_root/'learned').predict(frames[0].image)
                    except (FileNotFoundError,ValueError):pass
                    proposal=propose_scene(frames[0].image,box);proposals=list(proposal['lines']);atomic_json(self.session.root/'scene-proposals.json',proposal)
                    if box is not None:
                        x1,y1,x2,y2=box;corners=[[x1,y1],[x2,y1],[x2,y2],[x1,y2]]
                        proposals.extend({'points':[corners[i],corners[(i+1)%4]],'kind':'court_box_proposal','confirmed':False} for i in range(4))
                    # A coarse learned bounding box is not a court boundary.
                    # It must never admit/exclude participants without calibration.
                    outline=court_outline(frames[0].image,box)
                    if outline:proposal['floor_contour_proposal']=outline;atomic_json(self.session.root/'scene-proposals.json',proposal)
                    record['participant_geometry']=('manual' if self.session.geometry().get('court') else 'registered_reviewed_scene') if geometry.get('court') else 'unknown'
                    people_tracker.geometry=geometry
                before=time.perf_counter();predictions=model.predict(frames,pose_reader) if pose_reader else model.predict(frames)
                record['timings']['neural_s']=record['timings'].get('neural_s',0)+time.perf_counter()-before
                if len(predictions)!=len(frames):raise RuntimeError('Модель пропустила кадры')
                for frame,(people,balls) in zip(frames,predictions):
                    if self.stop.is_set():break
                    if pose_writer:pose_writer.add(frame.index,frame.time,people)
                    people=people_tracker.update(people,frame.image,frame.time);ball=ball_tracker.update(balls,frame.time,people)
                    for person in people:person['participant_geometry']=record['participant_geometry']
                    observation={'index':frame.index,'time':frame.time,'people':people,'ball':ball,
                        'ball_candidates':balls,'ball_missing':ball is None}
                    log.write(json.dumps(observation,ensure_ascii=False,allow_nan=False)+'\n')
                    before=time.perf_counter();painted=draw(frame.image,people,ball,geometry,proposals,self.layers)
                    writer.add(painted,frame.time);record['frames']+=1;record['last_time']=frame.time
                    record['timings']['draw_encode_s']=record['timings'].get('draw_encode_s',0)+time.perf_counter()-before
                    elapsed=time.perf_counter()-started
                    packet={'image':painted,'time':frame.time,'frames':record['frames'],'fps':record['frames']/max(.001,elapsed),
                        'speed_x':frame.time/max(.001,elapsed),'duration':meta['duration'],'device':model.device}
                    if not self.emit(packet):break
                log.flush();atomic_json(self.session.root/'analysis.json',record)
            if writer is None:raise ValueError('В записи нет доступных кадров')
            complete=not self.stop.is_set();record['status']='complete' if complete else 'cancelled'
        except Exception as exc:
            self.error=str(exc);record.update(status='failed',error=self.error)
        finally:
            if rows:rows.close()
            if log:log.close()
            if pose_reader:pose_reader.close()
            if pose_writer:pose_writer.close(complete)
            if writer:
                try:record['output']=str(writer.close(complete))
                except Exception as exc:self.error=str(exc);record.update(status='failed',error=self.error)
            if complete and not self.error:
                (self.session.root/'observations.partial.jsonl').replace(self.session.root/'observations.jsonl')
                try:record['audio_preserved']=preserve_audio(self.session.video,target)
                except Exception as exc:record['audio_warning']='Видео сохранено; исходный звук не перенесён: '+str(exc)
            record['wall_s']=time.perf_counter()-started;record['mean_fps']=record['frames']/max(.001,record['wall_s'])
            record['timing_scope']='Includes model startup, decode, inference, encoding and waiting for preview consumer. Not pure GPU inference FPS.'
            atomic_json(self.session.root/'analysis.json',record);self.result=record
