"""Optional ten-frame semantic correction, with original-pixel coordinates."""
import copy
import json

from PySide6 import QtCore as C,QtGui as G,QtWidgets as W
import cv2
import numpy as np

from .session import TOOLS


class EditorCanvas(W.QWidget):
    changed=C.Signal()
    def __init__(self):
        super().__init__();self.setMinimumSize(640,360);self.image=None;self.entries={};self.proposals=[];self.tool='court';self.drag=None;self.ratio=1;self.origin=C.QPointF()

    def set_frame(self,image,entries):self.image=image;self.entries=entries;self.update()

    def paintEvent(self,event):
        painter=G.QPainter(self);painter.fillRect(self.rect(),G.QColor('#14202b'))
        if self.image is None:return
        h,w=self.image.shape[:2];self.ratio=min(self.width()/w,self.height()/h)
        self.origin=C.QPointF((self.width()-w*self.ratio)/2,(self.height()-h*self.ratio)/2)
        rgb=cv2.cvtColor(self.image,cv2.COLOR_BGR2RGB);q=G.QImage(rgb.data,w,h,rgb.strides[0],G.QImage.Format.Format_RGB888)
        painter.translate(self.origin);painter.scale(self.ratio,self.ratio);painter.drawImage(C.QPointF(),q)
        painter.setRenderHint(G.QPainter.RenderHint.Antialiasing)
        painter.setPen(G.QPen(G.QColor('#999999'),1.5/self.ratio,C.Qt.PenStyle.DashLine))
        for points in self.proposals:
            painter.drawPolyline(G.QPolygonF([C.QPointF(x,y) for x,y in points]))
        for name,points in self.entries.items():
            if not points:continue
            label,kind,bgr=TOOLS[name];color=G.QColor(*reversed(bgr));painter.setPen(G.QPen(color,2/self.ratio));painter.setBrush(C.Qt.BrushStyle.NoBrush)
            polygon=G.QPolygonF([C.QPointF(x,y) for x,y in points])
            if kind=='polygon' and len(points)>2:painter.drawPolygon(polygon)
            elif kind in ('line','segment'):painter.drawPolyline(polygon)
            elif kind=='box' and len(points)==2:painter.drawRect(C.QRectF(polygon[0],polygon[1]).normalized())
            elif kind=='circle' and len(points)==2:
                radius=float(np.linalg.norm(np.array(points[0])-points[1]));painter.drawEllipse(polygon[0],radius,radius)
            for point in polygon:painter.drawEllipse(point,4/self.ratio,4/self.ratio)

    def position(self,event):
        p=(event.position()-self.origin)/self.ratio
        if self.image is None:return None
        h,w=self.image.shape[:2]
        return [float(p.x()),float(p.y())] if 0<=p.x()<w and 0<=p.y()<h else None

    def mousePressEvent(self,event):
        point=self.position(event)
        if point is None:return
        points=self.entries.setdefault(self.tool,[])
        if event.button()==C.Qt.MouseButton.RightButton:
            if points:points.pop();self.changed.emit();self.update()
            return
        for i,p in enumerate(points):
            if np.linalg.norm(np.array(point)-p)*self.ratio<10:self.drag=i;return
        kind=TOOLS[self.tool][1]
        if kind in ('segment','circle','box') and len(points)==2:points.clear()
        points.append(point);self.changed.emit();self.update()

    def mouseMoveEvent(self,event):
        point=self.position(event)
        if self.drag is not None and point is not None:
            self.entries[self.tool][self.drag]=point;self.changed.emit();self.update()

    def mouseReleaseEvent(self,event):self.drag=None


class CorrectionDialog(W.QDialog):
    def __init__(self,session,frames,parent=None):
        super().__init__(parent);self.session=session;self.frames=frames;self.index=0;self.cache={};self.setWindowTitle('Уточнить по 10 кадрам — необязательно');self.resize(1250,830)
        layout=W.QVBoxLayout(self);note=W.QLabel('Отмечайте только нужное. Серые пунктирные линии — предложения, цветные — ваши отметки. Антенны: низ у верхней кромки сетки → верх. Правый клик убирает последнюю точку. Точки можно перетаскивать.');note.setWordWrap(True);layout.addWidget(note)
        row=W.QHBoxLayout();layout.addLayout(row);self.canvas=EditorCanvas();row.addWidget(self.canvas,1)
        panel=W.QVBoxLayout();row.addLayout(panel);self.tools=W.QListWidget();panel.addWidget(self.tools)
        for name,(label,kind,bgr) in TOOLS.items():
            pix=G.QPixmap(14,14);pix.fill(G.QColor(*reversed(bgr)));item=W.QListWidgetItem(G.QIcon(pix),label);item.setData(C.Qt.ItemDataRole.UserRole,name);self.tools.addItem(item)
        self.tools.currentRowChanged.connect(self.select);self.tools.setCurrentRow(0)
        clear=W.QPushButton('Очистить выбранный элемент');clear.clicked.connect(self.clear);panel.addWidget(clear)
        self.status=W.QLabel();layout.addWidget(self.status)
        footer=W.QHBoxLayout();layout.addLayout(footer)
        for title,callback in [('← Предыдущий',lambda:self.move(-1)),('Следующий →',lambda:self.move(1)),('Сохранить исправления',self.save),('Закрыть',self.reject)]:
            button=W.QPushButton(title);button.clicked.connect(callback);footer.addWidget(button)
        try:
            proposal=json.loads((session.root/'scene-proposals.json').read_text(encoding='utf-8'))
            self.canvas.proposals=[r['points'] for r in proposal.get('lines',[]) if len(r.get('points',[]))>=2]
            box=proposal.get('court_box_proposal')
            if box:
                x1,y1,x2,y2=box;self.canvas.proposals.append([[x1,y1],[x2,y1],[x2,y2],[x1,y2],[x1,y1]])
        except (OSError,ValueError,KeyError):pass
        self.load()

    def select(self):
        item=self.tools.currentItem()
        if item:self.canvas.tool=item.data(C.Qt.ItemDataRole.UserRole)

    def clear(self):self.canvas.entries[self.canvas.tool]=[];self.canvas.update()

    def load(self):
        frame=self.frames[self.index]
        if self.index not in self.cache:
            existing=next((row for row in self.session.data['corrections'] if abs(row['time']-frame.time)<.001),None)
            self.cache[self.index]=copy.deepcopy(existing['entries'] if existing else self.session.geometry())
        self.canvas.set_frame(frame.image,self.cache[self.index]);self.status.setText(f'Кадр {self.index+1} из {len(self.frames)} · {frame.time:.3f} с. Сохранение не запускает обучение без проверки качества.')

    def move(self,step):self.index=max(0,min(len(self.frames)-1,self.index+step));self.load()

    def save(self):
        try:
            for index,entries in self.cache.items():
                if entries:self.session.correct(self.frames[index],entries)
            self.accept()
        except (ValueError,OSError) as exc:W.QMessageBox.warning(self,'Разметка',str(exc))
