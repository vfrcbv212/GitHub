"""Small reviewed-learning heads; pretrained runtime models remain immutable."""
import hashlib
import json
from pathlib import Path
import re

import cv2
import numpy as np
import torch
from torch import nn

from .session import atomic_json


class BallVerifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.network=nn.Sequential(nn.Conv2d(3,16,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(16,32,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(32,32,3,padding=1),nn.ReLU(),nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Linear(32,1))

    def forward(self,x):return self.network(x).squeeze(1)


class CourtBoxHead(nn.Module):
    def __init__(self):
        super().__init__();self.network=nn.Sequential(nn.Linear(576,128),nn.ReLU(),nn.Linear(128,4),nn.Sigmoid())

    def forward(self,x):return self.network(x)


def source_group(name):
    stem=Path(name).stem
    # All augmentation variants and frames of the same named match stay together.
    return re.split(r'[_-]\d+_jpg|_jpg\.rf|[_-]frame[_-]?\d+',stem)[0]


def catalogue(folder):
    records=[];bad=[];seen=set()
    for image in sorted(Path(folder).rglob('images/*.jpg')):
        raw=image.read_bytes();sha=hashlib.sha256(raw).hexdigest()
        if sha in seen:continue
        seen.add(sha);label=image.parent.parent/'labels'/(image.stem+'.txt')
        if not label.exists():bad.append({'image':str(image),'reason':'missing labels'});continue
        boxes=[]
        try:
            for line in label.read_text().splitlines():
                if not line.strip():continue
                category,x,y,w,h=map(float,line.split())
                if category!=0 or min(x,y,w,h)<0 or max(x,y,w,h)>1 or w*h==0:raise ValueError('invalid box')
                boxes.append([max(0,x-w/2),max(0,y-h/2),min(1,x+w/2),min(1,y+h/2)])
        except ValueError:bad.append({'image':str(image),'reason':'invalid YOLO label'});continue
        records.append({'image':str(image),'sha256':sha,'group':source_group(image.name),'boxes':boxes})
    return records,bad


def split_groups(records,seed=13):
    groups=sorted({r['group'] for r in records});rng=np.random.default_rng(seed);rng.shuffle(groups)
    if len(groups)<3:raise ValueError('Нужны минимум три независимые записи для обучения/проверки/теста')
    test=set(groups[:max(1,len(groups)//10)]);val=set(groups[len(test):len(test)+max(1,len(groups)//5)])
    splits={'train':[],'validation':[],'test':[]}
    for row in records:splits['test' if row['group'] in test else 'validation' if row['group'] in val else 'train'].append(row)
    return splits


def image_tensor(image,size):
    small=cv2.cvtColor(cv2.resize(image,(size,size)),cv2.COLOR_BGR2RGB)
    return torch.from_numpy(small.transpose(2,0,1).copy()).float()/255


def patches(records,seed=3):
    rng=np.random.default_rng(seed);xs=[];ys=[]
    for row in records:
        image=cv2.imdecode(np.fromfile(row['image'],np.uint8),cv2.IMREAD_COLOR)
        if image is None:raise ValueError('Image decode failed')
        h,w=image.shape[:2]
        centers=[((b[0]+b[2])*w/2,(b[1]+b[3])*h/2) for b in row['boxes']]
        for x,y in centers:
            radius=20;cx=int(x);cy=int(y)
            crop=image[max(0,cy-radius):min(h,cy+radius),max(0,cx-radius):min(w,cx+radius)]
            if crop.size:xs.append(image_tensor(crop,32));ys.append(1.)
        for _ in range(max(1,len(centers))*2):
            for attempt in range(30):
                cx=int(rng.integers(20,max(21,w-20)));cy=int(rng.integers(20,max(21,h-20)))
                if all(abs(cx-x)>40 or abs(cy-y)>40 for x,y in centers):break
            else:continue
            crop=image[max(0,cy-20):min(h,cy+20),max(0,cx-20):min(w,cx+20)]
            if crop.size:xs.append(image_tensor(crop,32));ys.append(0.)
    return torch.stack(xs),torch.tensor(ys)


def box_iou(predictions,targets):
    low=torch.maximum(predictions[:,:2],targets[:,:2]);high=torch.minimum(predictions[:,2:],targets[:,2:])
    intersection=(high-low).clamp_min(0).prod(1)
    area=(predictions[:,2:]-predictions[:,:2]).clamp_min(0).prod(1)+(targets[:,2:]-targets[:,:2]).clamp_min(0).prod(1)-intersection
    return intersection/area.clamp_min(1e-8)


def train_heads(data_root,output,epochs=8,progress=print):
    """Train small auxiliary heads on real upstream-labelled photographs.

    This does NOT retrain YOLO poses or the temporal volleyball model, and does
    not convert court bounding boxes into ground-truth boundary lines.
    """
    from torchvision.models import mobilenet_v3_small,MobileNet_V3_Small_Weights
    torch.manual_seed(19);torch.set_num_threads(2);output=Path(output);output.mkdir(parents=True,exist_ok=True)
    ball,bad_ball=catalogue(Path(data_root)/'dataset_ball_blurred')
    court,bad_court=catalogue(Path(data_root)/'dataset_with_test_frames_and_augs')
    split_ball=split_groups(ball);split_court=split_groups(court)
    inventory={'tasks':{},'rejected_labels':bad_ball+bad_court,'status':'running',
        'not_retrained':['YOLO body poses','VballNet temporal model','semantic net/antenna lines'],
        'upstream_labels_independently_fully_reviewed':False,'automatic_activation':False}
    for name,splits in [('ball_verifier',split_ball),('court_box',split_court)]:
        inventory['tasks'][name]={key:{'photographs':len(rows),'groups':sorted({r['group'] for r in rows})} for key,rows in splits.items()}
    inventory['training_photo_count']=len(split_ball['train'])+len(split_court['train'])
    atomic_json(output/'training.json',inventory)
    progress('Ball verifier: preparing patches')
    data={key:patches(rows) for key,rows in split_ball.items()};net=BallVerifier();optimizer=torch.optim.AdamW(net.parameters(),lr=.002)
    history=[]
    for epoch in range(epochs):
        net.train();x,y=data['train'];order=torch.randperm(len(y));losses=[]
        for indices in order.split(128):
            logits=net(x[indices]);loss=nn.functional.binary_cross_entropy_with_logits(logits,y[indices]);optimizer.zero_grad();loss.backward();optimizer.step();losses.append(float(loss))
        net.eval()
        with torch.inference_mode():
            vx,vy=data['validation'];probabilities=net(vx).sigmoid()
            threshold=float(torch.quantile(probabilities[vy==1],.02)) if (vy==1).any() else .5
            predicted=probabilities>=threshold;recall=float(predicted[vy==1].float().mean());fpr=float(predicted[vy==0].float().mean())
        row={'epoch':epoch+1,'loss':float(np.mean(losses)),'validation_recall':recall,'validation_false_positive_rate':fpr,'threshold':threshold}
        history.append(row);progress(json.dumps({'ball':row}));torch.save({'state_dict':net.state_dict(),'threshold':threshold,'epoch':epoch+1},output/'ball-verifier-candidate.pt')
        atomic_json(output/'ball-history.json',history)
    with torch.inference_mode():
        x,y=data['test'];predicted=net(x).sigmoid()>=threshold
        test_ball={'recall':float(predicted[y==1].float().mean()),'false_positive_rate':float(predicted[y==0].float().mean()),'patches':len(y)}
    progress('Court box: extracting pretrained MobileNet features')
    backbone=mobilenet_v3_small(weights=MobileNet_V3_Small_Weights.DEFAULT).features.eval()
    mean=torch.tensor([.485,.456,.406])[None,:,None,None];std=torch.tensor([.229,.224,.225])[None,:,None,None]
    court_data={}
    for key,rows in split_court.items():
        rows=[row for row in rows if row['boxes']];features=[];targets=[]
        for i in range(0,len(rows),32):
            batch=rows[i:i+32];images=[cv2.imdecode(np.fromfile(row['image'],np.uint8),cv2.IMREAD_COLOR) for row in batch]
            tensor=torch.stack([image_tensor(image,192) for image in images])
            with torch.inference_mode():vectors=backbone((tensor-mean)/std).mean((2,3)).detach().clone()
            features.append(vectors);targets.extend(max(row['boxes'],key=lambda b:(b[2]-b[0])*(b[3]-b[1])) for row in batch)
        court_data[key]=(torch.cat(features),torch.tensor(targets))
    torch.save(backbone.state_dict(),output/'court-backbone.pt')
    head=CourtBoxHead();optimizer=torch.optim.AdamW(head.parameters(),lr=.002);history=[]
    for epoch in range(max(30,epochs*10)):
        x,y=court_data['train'];order=torch.randperm(len(y));head.train()
        for indices in order.split(64):
            loss=nn.functional.smooth_l1_loss(head(x[indices]),y[indices]);optimizer.zero_grad();loss.backward();optimizer.step()
        if epoch%10==0:progress(f'Court head epoch {epoch+1}')
    with torch.inference_mode():
        x,y=court_data['validation'];validation_iou=float(box_iou(head(x),y).mean())
        median=court_data['train'][1].median(0).values.expand_as(y);baseline_iou=float(box_iou(median,y).mean())
        x,y=court_data['test'];test_iou=float(box_iou(head(x),y).mean())
    torch.save(head.state_dict(),output/'court-head-candidate.pt')
    inventory.update(status='complete',ball_test=test_ball,ball_verifier_eligible=recall>=.98 and fpr<=.2,
        court_validation_iou=validation_iou,
        court_validation_constant_baseline_iou=baseline_iou,court_test_iou=test_iou,
        court_proposal_eligible=validation_iou>=.65 and validation_iou>=baseline_iou+.03)
    atomic_json(output/'training.json',inventory);return inventory


class CourtProposer:
    def __init__(self,folder):
        from torchvision.models import mobilenet_v3_small
        folder=Path(folder);record=json.loads((folder/'training.json').read_text())
        if record.get('status')!='complete' or not record.get('court_proposal_eligible'):raise ValueError('Court candidate did not pass validation')
        self.backbone=mobilenet_v3_small(weights=None).features.eval();self.head=CourtBoxHead().eval()
        self.backbone.load_state_dict(torch.load(folder/'court-backbone.pt',map_location='cpu',weights_only=True))
        self.head.load_state_dict(torch.load(folder/'court-head-candidate.pt',map_location='cpu',weights_only=True))

    def predict(self,image):
        tensor=image_tensor(image,192)[None];mean=tensor.new_tensor([.485,.456,.406])[None,:,None,None];std=tensor.new_tensor([.229,.224,.225])[None,:,None,None]
        with torch.inference_mode():box=self.head(self.backbone((tensor-mean)/std).mean((2,3)))[0].tolist()
        h,w=image.shape[:2];x1,y1,x2,y2=box
        return [min(x1,x2)*w,min(y1,y2)*h,max(x1,x2)*w,max(y1,y2)*h]
