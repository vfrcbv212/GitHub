"""Presentation deadlines without cumulative timer drift or skipped frames."""


class PlaybackClock:
    def __init__(self):self.reset()

    def reset(self):self.previous_source=None;self.previous_deadline=None;self.pending_source=None;self.pending_deadline=None

    def ready(self,source_time,now):
        if self.pending_source!=source_time:
            self.pending_source=source_time
            self.pending_deadline=now if self.previous_source is None else self.previous_deadline+max(0,source_time-self.previous_source)
            # Slow inference may delay the stream, but never trigger a burst of
            # skipped or instantly presented frames to catch the source clock.
            if now-self.pending_deadline>.1:self.pending_deadline=now
        if now<self.pending_deadline:return False
        self.previous_source=source_time;self.previous_deadline=self.pending_deadline
        self.pending_source=None;return True
