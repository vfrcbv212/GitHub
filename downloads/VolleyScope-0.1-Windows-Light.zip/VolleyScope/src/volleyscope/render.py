import cv2
import numpy as np

from .session import TOOLS
from .text import label as draw_label

SKELETON=[(5,6),(5,7),(7,9),(6,8),(8,10),(5,11),(6,12),(11,12),(11,13),(13,15),(12,14),(14,16),(0,1),(0,2),(1,3),(2,4)]


def draw(image,people=(),ball=None,geometry=None,proposals=(),layers=None):
    result=image.copy();h,w=result.shape[:2];thickness=max(1,round(w/700))
    if layers is None:layers={'court','net','people','ball','proposals'}
    for name,points in (geometry or {}).items():
        layer='net' if name.startswith(('net','antenna')) else 'court'
        if layer not in layers or len(points)<2:continue
        color=TOOLS.get(name,('',None,(255,255,255)))[2];vertices=np.array(points,np.int32)
        if name=='referee' and len(vertices)==2:cv2.rectangle(result,tuple(vertices[0]),tuple(vertices[1]),color,thickness,cv2.LINE_AA)
        else:cv2.polylines(result,[vertices],name=='court',color,thickness,cv2.LINE_AA)
    if 'proposals' in layers:
        for proposal in proposals:
            a,b=np.array(proposal['points'],np.int32)
            # Dashed, subdued candidates are distinct from manually labelled lines.
            for fraction in np.arange(0,1,.1):
                p=(a+(b-a)*fraction).astype(int);q=(a+(b-a)*min(1,fraction+.05)).astype(int)
                cv2.line(result,tuple(p),tuple(q),(130,130,130),1,cv2.LINE_AA)
    if 'people' in layers:
        for person in people:
            active=person.get('participant');referee=person.get('referee');team=person.get('team')
            color=(80,200,255) if team=='A' else (255,170,90) if team=='B' else (110,110,110)
            if referee:color=(80,80,255)
            x1,y1,x2,y2=map(int,person['bbox']);cv2.rectangle(result,(x1,y1),(x2,y2),color,thickness)
            label='Судья' if referee else f"Игрок {person['track_id']}" if active else f"Человек {person.get('track_id','?')} · статус ?"
            if team:label+=' / '+team
            if person.get('identity_uncertain'):label+=' ?'
            draw_label(result,label,x1,y1-25,color,max(14,round(w/105)))
            joints=person.get('joints',[])
            for a,b in SKELETON:
                if len(joints)>max(a,b) and joints[a][2]>.35 and joints[b][2]>.35:
                    cv2.line(result,tuple(map(int,joints[a][:2])),tuple(map(int,joints[b][:2])),color,thickness,cv2.LINE_AA)
            for x,y,confidence in joints:
                if confidence>.35:cv2.circle(result,(int(x),int(y)),thickness+1,color,-1,cv2.LINE_AA)
    if 'ball' in layers and ball:
        x,y=map(int,ball['point']);cv2.circle(result,(x,y),max(5,thickness*3),(60,255,80),thickness,cv2.LINE_AA)
        trail=np.array(ball.get('trail',[]),np.int32)
        if len(trail)>1:cv2.polylines(result,[trail],False,(60,255,80),thickness,cv2.LINE_AA)
    return result
