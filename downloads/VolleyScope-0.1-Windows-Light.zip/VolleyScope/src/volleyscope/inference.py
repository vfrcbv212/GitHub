"""Fresh integration of COCO body poses and a volleyball temporal ball model."""
import cv2
import numpy as np

from .assets import verified


class NeuralModels:
    supports_pose_cache=True
    def __init__(self,root,device='auto',pose_size=960,load_pose=True):
        import torch
        import onnxruntime as ort
        from ultralytics import YOLO
        self.warning=None
        self.device='cuda' if device!='cpu' and torch.cuda.is_available() else 'cpu'
        if device=='cuda' and self.device!='cuda':raise ValueError('CUDA недоступна')
        if self.device=='cuda':
            try:(torch.ones(1,device='cuda')+1).cpu()
            except RuntimeError as exc:
                if device=='cuda':raise ValueError('CUDA не выполняет вычисления: '+str(exc)) from exc
                self.device='cpu';self.warning='Проверка CUDA не прошла; выбран CPU: '+str(exc)
        torch.set_num_threads(2 if self.device=='cpu' else 4)
        self.pose=YOLO(str(verified(root,'pose'))) if load_pose else None;self.pose_size=pose_size
        options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
        self.ball=ort.InferenceSession(str(verified(root,'ball')),sess_options=options,providers=['CPUExecutionProvider'])
        self.ball_input=self.ball.get_inputs()[0];self.seq=int(self.ball_input.shape[1])
        self.h=int(self.ball_input.shape[2]);self.w=int(self.ball_input.shape[3])
        self.history=[]

    def predict(self,frames,pose_reader=None):
        """Every real input frame gets one pose result and one temporal heatmap."""
        import torch
        count=len(frames)
        if not 1<=count<=self.seq:raise ValueError('Неверный размер последовательности')
        images=[f.image for f in frames];batch=3 if self.device=='cuda' else 1;people=[];offset=0
        if pose_reader:people=[pose_reader.read(frame.index,frame.time) for frame in frames];offset=count
        while offset<count:
            selected=images[offset:offset+batch]
            try:
                results=self.pose.predict(selected,imgsz=self.pose_size,conf=.3,iou=.5,device=self.device,
                    quantize=16 if self.device=='cuda' else None,verbose=False,save=False)
            except torch.cuda.OutOfMemoryError:
                if batch==1:raise
                torch.cuda.empty_cache();batch=max(1,batch//2);continue
            for result in results:
                boxes=result.boxes.xyxy.cpu().numpy();scores=result.boxes.conf.cpu().numpy()
                joints=result.keypoints.data.cpu().numpy() if result.keypoints is not None else np.zeros((len(boxes),17,3))
                people.append([{'bbox':b.tolist(),'score':float(s),'joints':j.tolist()} for b,s,j in zip(boxes,scores,joints)])
            offset+=len(selected)
        # A full window is evaluated without skipped frames. The final short
        # window uses real preceding context, never duplicated future frames.
        context=(self.history+images)[-self.seq:]
        pad=self.seq-len(context);input_images=[context[0]]*pad+context
        tensor=np.stack([cv2.resize(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(self.w,self.h)) for im in input_images])[None].astype(np.float32)/255
        output=self.ball.run(None,{self.ball_input.name:tensor})[0][0]
        heatmaps=output[:self.seq]
        if heatmaps.min()<0 or heatmaps.max()>1:heatmaps=1/(1+np.exp(-np.clip(heatmaps,-40,40)))
        ball_rows=[]
        for frame,heat in zip(frames,heatmaps[-count:]):
            count_components,labels,stats,centers=cv2.connectedComponentsWithStats((heat>=.35).astype(np.uint8))
            candidates=[];h,w=frame.image.shape[:2]
            for label in range(1,count_components):
                area=int(stats[label,cv2.CC_STAT_AREA])
                if area<2:continue
                mask=labels==label;values=heat[mask];ys,xs=np.where(mask);total=float(values.sum())
                x=float((xs*values).sum()/max(total,1e-8));y=float((ys*values).sum()/max(total,1e-8))
                candidates.append({'point':[x*w/self.w,y*h/self.h],'score':float(values.max()),'support':total,'observed':True})
            ball_rows.append(sorted(candidates,key=lambda c:c['support'],reverse=True)[:5])
        self.history=(self.history+images)[-(self.seq-1):]
        return list(zip(people,ball_rows))
