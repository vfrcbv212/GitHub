"""Simple local video workflow. Inference never blocks the Qt event loop."""
import argparse
from pathlib import Path
import queue
import sys
import threading
import time

import cv2
from PySide6 import QtCore as C,QtGui as G,QtWidgets as W

from .assets import prepare
from .annotation_ui import CorrectionDialog
from .engine import AnalysisEngine
from .media import at
from .session import Session,select_ten
from .playback import PlaybackClock


class VideoView(W.QLabel):
    def __init__(self):
        super().__init__('Откройте видео');self.setMinimumSize(640,360);self.setAlignment(C.Qt.AlignmentFlag.AlignCenter);self.setStyleSheet('background:#14202b;color:#dce7f0');self.original=None

    def display(self,bgr):
        rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB);h,w=rgb.shape[:2]
        self.original=G.QPixmap.fromImage(G.QImage(rgb.data,w,h,rgb.strides[0],G.QImage.Format.Format_RGB888).copy());self.fit()

    def fit(self):
        if self.original:self.setPixmap(self.original.scaled(self.size(),C.Qt.AspectRatioMode.KeepAspectRatio,C.Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self,event):super().resizeEvent(event);self.fit()


class TaskSignals(C.QObject):
    done=C.Signal(object);failed=C.Signal(str);progress=C.Signal(str)


class Task(C.QRunnable):
    def __init__(self,fn):super().__init__();self.fn=fn;self.signals=TaskSignals();self.cancelled=threading.Event()
    def run(self):
        try:self.signals.done.emit(self.fn(self.signals.progress.emit,self.cancelled.is_set))
        except Exception as exc:self.signals.failed.emit(str(exc))


class Window(W.QMainWindow):
    def __init__(self,home):
        super().__init__();self.home=Path(home);self.home.mkdir(parents=True,exist_ok=True);self.session=None;self.engine=None;self.task=None;self.pending=None;self.output_path=None
        self.clock=PlaybackClock();self.setWindowTitle('VolleyScope — новая версия');self.resize(1360,880)
        outer=W.QWidget();self.setCentralWidget(outer);layout=W.QVBoxLayout(outer)
        row=W.QHBoxLayout();layout.addLayout(row)
        self.open_button=W.QPushButton('Открыть видео');self.open_button.clicked.connect(self.open_video);row.addWidget(self.open_button)
        self.prepare_button=W.QPushButton('Подготовить модели');self.prepare_button.clicked.connect(self.prepare_models);row.addWidget(self.prepare_button)
        self.correct_button=W.QPushButton('Уточнить по 10 кадрам');self.correct_button.clicked.connect(self.correct);row.addWidget(self.correct_button)
        self.start_button=W.QPushButton('Начать анализ');self.start_button.clicked.connect(self.start);row.addWidget(self.start_button)
        self.pause_button=W.QPushButton('Пауза');self.pause_button.clicked.connect(self.pause);row.addWidget(self.pause_button)
        self.stop_button=W.QPushButton('Остановить');self.stop_button.clicked.connect(self.stop);row.addWidget(self.stop_button)
        self.output_button=W.QPushButton('Открыть результат');self.output_button.clicked.connect(self.open_output);row.addWidget(self.output_button)
        self.view=VideoView();layout.addWidget(self.view,1)
        row=W.QHBoxLayout();layout.addLayout(row);self.layers={}
        for key,title in [('court','Площадка'),('net','Сетка и антенны'),('people','Игроки и суставы'),('ball','Мяч'),('proposals','Подсказки линий и области')]:
            check=W.QCheckBox(title);check.setChecked(key!='proposals');self.layers[key]=check;row.addWidget(check)
        self.progress=W.QProgressBar();layout.addWidget(self.progress)
        self.status=W.QLabel('Откройте видео. Разметка необязательна. Анализ обрабатывает каждый кадр; воспроизведение замедляется, если вычисления не успевают.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.limit=W.QLabel('Люди и мяч: предобученные нейросети. Полностью автоматические линии сетки, антенны и роль судьи пока требуют разметки. Предложения площадки остаются гипотезами.');self.limit.setWordWrap(True);layout.addWidget(self.limit)
        self.timer=C.QTimer(self);self.timer.setInterval(2);self.timer.setTimerType(C.Qt.TimerType.PreciseTimer);self.timer.timeout.connect(self.tick);self.timer.start()
        self.update_buttons()

    def update_buttons(self):
        busy=bool(self.task or self.engine)
        self.open_button.setEnabled(not busy);self.prepare_button.setEnabled(not busy);self.correct_button.setEnabled(not busy and self.session is not None);self.start_button.setEnabled(not busy and self.session is not None)
        self.pause_button.setEnabled(self.engine is not None);self.stop_button.setEnabled(busy)
        self.output_button.setEnabled(not busy and self.output_path is not None and Path(self.output_path).is_file())
        for check in self.layers.values():check.setEnabled(not busy)

    def background(self,fn,done):
        if self.task or self.engine:return
        self.task=Task(fn);self.task.signals.progress.connect(self.status.setText)
        def completed(result):self.task=None;self.update_buttons();done(result)
        def failed(text):self.task=None;self.update_buttons();self.error(text)
        self.task.signals.done.connect(completed);self.task.signals.failed.connect(failed);self.update_buttons();C.QThreadPool.globalInstance().start(self.task)

    def error(self,text):self.status.setText(text);W.QMessageBox.warning(self,'VolleyScope',text)

    def open_video(self):
        filename,_=W.QFileDialog.getOpenFileName(self,'Видео с неподвижной камеры',filter='Видео (*.mp4 *.MP4 *.mov *.MOV)')
        if filename:self.load_video(filename)

    def load_video(self,path):
        def task(progress,cancel):
            from .media import fingerprint
            progress('Открытие и проверка видео…');digest=fingerprint(path);session=Session(self.home/'sessions'/digest[:16],path);return session,at(path,0)
        def done(result):
            self.session,frame=result;self.view.display(frame.image);self.output_path=self.session.root/'annotated.mp4';meta=self.session.data['metadata'];self.status.setText(f"{Path(path).name} · {meta['width']}×{meta['height']} · {meta['fps']:.3f} FPS · {meta['duration']:.1f} с");self.update_buttons()
        self.background(task,done)

    def prepare_models(self):
        self.background(lambda progress,cancel:prepare(self.home/'models',progress,cancel),lambda result:self.status.setText('Модели готовы. Обычный анализ работает без сети.'))

    def correct(self):
        if not self.session:return
        def task(progress,cancel):
            progress('Выбор резких кадров из десяти частей записи…');return select_ten(self.session.video,cancel=cancel)
        def done(frames):
            if frames:CorrectionDialog(self.session,frames,self).exec();self.status.setText('Исправления сохранены в проекте и доступны для последующего обучения.')
        self.background(task,done)

    def start(self):
        if self.engine or not self.session:return
        self.engine=AnalysisEngine(self.session,self.home/'models',{key for key,check in self.layers.items() if check.isChecked()})
        self.clock.reset();self.pending=None;self.output_path=None;self.engine.start();self.status.setText('Загрузка моделей и начало анализа…');self.update_buttons()

    def open_output(self):
        if self.output_path and Path(self.output_path).is_file():G.QDesktopServices.openUrl(C.QUrl.fromLocalFile(str(Path(self.output_path).resolve())))

    def pause(self):
        if not self.engine:return
        if self.engine.paused.is_set():self.engine.paused.clear();self.pause_button.setText('Пауза');self.clock.reset()
        else:self.engine.paused.set();self.pause_button.setText('Продолжить')

    def stop(self):
        if self.task:self.task.cancelled.set()
        if self.engine:self.engine.stop.set();self.status.setText('Остановка и закрытие видеофайла…')

    def tick(self):
        if not self.engine:return
        if self.engine.paused.is_set() and not self.engine.stop.is_set():return
        if self.pending is None:
            try:self.pending=self.engine.packets.get_nowait()
            except queue.Empty:pass
        if self.pending is not None:
            packet=self.pending;now=time.monotonic()
            if not self.clock.ready(packet['time'],now):return
            self.view.display(packet['image']);self.pending=None
            self.progress.setValue(round(100*packet['time']/max(.001,packet['duration'])))
            self.status.setText(f"{packet['device'].upper()} · кадр {packet['frames']} · {packet['time']:.2f} / {packet['duration']:.2f} с · {packet['fps']:.1f} кадров/с обработки")
        if self.engine.result is not None and self.engine.packets.empty() and self.pending is None:
            result=self.engine.result;error=self.engine.error;self.engine=None;self.output_path=result.get('output');self.pause_button.setText('Пауза');self.update_buttons()
            self.status.setText(f"{result['status']} · обработано {result['frames']} кадров · {result['mean_fps']:.1f} кадров/с. Видео: {result.get('output','не создано')}")
            if error:self.error(error)

    def closeEvent(self,event):
        if self.engine or self.task:self.stop();event.ignore();return
        self.timer.stop();event.accept()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--home',type=Path,default=Path.cwd());args=parser.parse_args()
    app=W.QApplication.instance() or W.QApplication(sys.argv);app.setStyle('Fusion');window=Window(args.home);window.show();return app.exec()


if __name__=='__main__':raise SystemExit(main())
