"""Conservative automatic line proposals; manual semantic labels take priority."""
import cv2
import numpy as np


def propose_scene(image,court_box=None):
    h,w=image.shape[:2];scale=min(1,960/w);small=cv2.resize(image,None,fx=scale,fy=scale)
    gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY);edges=cv2.Canny(gray,65,160)
    rows=cv2.HoughLinesP(edges,1,np.pi/720,threshold=70,minLineLength=small.shape[1]*.14,maxLineGap=25)
    proposals=[]
    for line in (() if rows is None else rows[:,0]):
        points=(line.reshape(2,2)/scale).tolist();length=float(np.linalg.norm(line[:2]-line[2:]))
        if any(np.linalg.norm(np.array(points[0])-r['points'][0])<15 and np.linalg.norm(np.array(points[1])-r['points'][1])<15 for r in proposals):continue
        proposals.append({'points':points,'score':min(1,length/(small.shape[1]*.8)),
                          'kind':'unclassified_line','confirmed':False})
    proposals=sorted(proposals,key=lambda row:row['score'],reverse=True)[:30]
    return {'lines':proposals,'court_box_proposal':court_box,'semantic_geometry':{},
            'limitation':'Отрезки ещё не классифицированы как сетка/три метра/центр. Нужна проверенная модель ориентиров или ручные метки.'}


def court_outline(image,box):
    """A floor contour proposal, never a verified boundary for player exclusion."""
    if box is None:return None
    x1,y1,x2,y2=map(int,box);h,w=image.shape[:2]
    x1=max(0,x1);y1=max(0,y1);x2=min(w,x2);y2=min(h,y2)
    crop=image[y1:y2,x1:x2]
    if crop.size==0:return None
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)
    # No fixed court colour. Dominant floor cluster supplies only a proposal.
    pixels=hsv.reshape(-1,3).astype(np.float32);sample=pixels[::max(1,len(pixels)//20000)]
    _,_,centers=cv2.kmeans(sample,4,None,(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,20,.5),2,cv2.KMEANS_PP_CENTERS)
    best=None
    for center in centers:
        distance=np.linalg.norm((pixels-center)*np.array([1, .6,.4]),axis=1).reshape(crop.shape[:2])
        mask=(distance<30).astype(np.uint8)*255;mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((15,15),np.uint8))
        contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            area=cv2.contourArea(contour)
            if area<.15*crop.shape[0]*crop.shape[1]:continue
            polygon=cv2.approxPolyDP(cv2.convexHull(contour),.025*cv2.arcLength(contour,True),True).reshape(-1,2)
            if 3<=len(polygon)<=10 and (best is None or area>best[0]):best=(area,(polygon+[x1,y1]).tolist())
    return best[1] if best else None
