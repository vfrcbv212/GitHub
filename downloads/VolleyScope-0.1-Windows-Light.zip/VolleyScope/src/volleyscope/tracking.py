"""Anonymous identity continuity with explicit uncertainty and participant memory."""
from dataclasses import dataclass,field
import math

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment


def iou(a,b):
    x=max(0,min(a[2],b[2])-max(a[0],b[0]));y=max(0,min(a[3],b[3])-max(a[1],b[1]))
    intersection=x*y;return intersection/max(1,(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-intersection)


def inside(polygon,point):
    return bool(polygon and cv2.pointPolygonTest(np.asarray(polygon,np.float32),tuple(map(float,point)),False)>=0)


def descriptor(image,bbox):
    h,w=image.shape[:2];x1,y1,x2,y2=map(int,bbox);crop=image[max(0,y1):min(h,y2),max(0,x1):min(w,x2)]
    if crop.size==0:return np.zeros(96,np.float32)
    crop=cv2.resize(crop,(32,96));hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV);vectors=[]
    for start,end in ((0,32),(32,64),(64,96)):
        histogram=cv2.calcHist([hsv[start:end]],[0,1],None,[8,4],[0,180,0,256]).flatten();vectors.append(histogram)
    value=np.concatenate(vectors);return value/max(np.linalg.norm(value),1e-8)


def anchor(person):
    joints=person.get('joints',[])
    ankles=[j[:2] for j in joints[15:17] if j[2]>.4]
    return np.mean(ankles,axis=0).tolist() if ankles else [(person['bbox'][0]+person['bbox'][2])/2,person['bbox'][3]]


@dataclass
class PersonTrack:
    id:int
    bbox:list
    appearance:object
    last_time:float
    participant:bool=False
    team:str|None=None
    referee:bool=False
    inside_hits:int=0
    votes:list=field(default_factory=list)
    uncertain_return:bool=False


class PeopleTracker:
    def __init__(self,geometry=None,corrections=()):
        self.geometry=geometry or {};self.corrections=corrections;self.tracks={};self.next_id=1
        self.team_signs={};self.initial_team_members={'A':set(),'B':set()}

    def update(self,people,image,timestamp):
        self.current_people=people
        vectors=[descriptor(image,p['bbox']) for p in people];ids=[k for k,t in self.tracks.items() if timestamp-t.last_time<=30]
        costs=np.full((len(ids),len(people)),10.,np.float32)
        diagonal=math.hypot(*image.shape[:2])
        for i,tid in enumerate(ids):
            track=self.tracks[tid];gap=timestamp-track.last_time
            for j,p in enumerate(people):
                similarity=float(np.dot(track.appearance,vectors[j]));overlap=iou(track.bbox,p['bbox'])
                distance=np.linalg.norm(np.asarray(track.bbox[:2])-p['bbox'][:2])/diagonal
                if gap<.6 and (overlap>.05 or distance<.05):costs[i,j]=.65*(1-overlap)+.35*(1-similarity)
                elif track.participant and gap<2 and similarity>.96 and distance<.08:
                    alternatives=sorted([float(np.dot(other.appearance,vectors[j])) for other in self.tracks.values() if other.id!=tid and timestamp-other.last_time<=30],reverse=True)
                    if not alternatives or similarity-alternatives[0]>.06:costs[i,j]=.85+(1-similarity)
        matches={}
        if costs.size:
            for i,j in zip(*linear_sum_assignment(costs)):
                if costs[i,j]<.94:matches[j]=ids[i]
        for j,person in enumerate(people):
            tid=matches.get(j)
            if tid is None:
                tid=self.next_id;self.next_id+=1;track=PersonTrack(tid,person['bbox'],vectors[j],timestamp);self.tracks[tid]=track
            else:
                track=self.tracks[tid];track.uncertain_return=timestamp-track.last_time>=.6
                if timestamp-track.last_time<.6:track.appearance=.9*track.appearance+.1*vectors[j];track.appearance/=max(1e-8,np.linalg.norm(track.appearance))
            self.assign_role(track,person,timestamp)
            track.bbox=person['bbox'];track.last_time=timestamp
            person.update(track_id=tid,participant=track.participant,team=track.team,referee=track.referee,
                          identity_uncertain=track.uncertain_return)
        self.tracks={k:v for k,v in self.tracks.items() if timestamp-v.last_time<=120}
        return people

    def assign_role(self,track,person,timestamp):
        point=anchor(person)
        for row in self.corrections:
            if abs(row['time']-timestamp)>.1:continue
            entries=row['entries']
            if 'referee' in entries and len(entries['referee'])==2:
                a,b=entries['referee'];box=[min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1])]
                matches=[p for p in self.current_people if iou(box,p['bbox'])>.5]
                if len(matches)==1 and matches[0] is person:track.referee=True;track.participant=False;track.team=None
            for team,key in (('A','team_a'),('B','team_b')):
                for x,y in entries.get(key,[]):
                    b=person['bbox']
                    matches=[p for p in self.current_people if p['bbox'][0]<=x<=p['bbox'][2] and p['bbox'][1]<=y<=p['bbox'][3]]
                    if len(matches)==1 and matches[0] is person and not track.referee:
                        track.participant=True;track.team=team
        if track.referee:return
        if inside(self.geometry.get('court'),point):track.inside_hits+=1
        else:track.inside_hits=max(0,track.inside_hits-1)
        if track.inside_hits>=5:track.participant=True
        # A player already admitted stays active outside the boundary (serve,
        # defensive save). A new spectator outside never becomes a participant.
        line=self.geometry.get('center',[])
        if track.participant and track.team is None and len(line)>=2:
            a=np.array(line[0]);b=np.array(line[-1]);delta=b-a;cross=float(np.cross(delta,np.array(point)-a))
            distance=abs(cross)/max(1,np.linalg.norm(delta))
            if distance>12:
                track.votes.append('A' if cross>0 else 'B');track.votes=track.votes[-10:]
                if len(track.votes)>=5:
                    team=max(set(track.votes),key=track.votes.count)
                    if track.votes.count(team)>=.8*len(track.votes):track.team=team


class BallTracker:
    def __init__(self,corrections=()):
        self.last=None;self.time=None;self.velocity=np.zeros(2);self.trail=[];self.corrections=corrections
        self.history=[];self.stationary_anchor=None;self.stationary_since=None;self.manual_track=False

    def update(self,candidates,timestamp,people=()):
        self.history.append((timestamp,candidates));self.history=self.history[-3:]
        if not candidates:
            if self.time is not None and timestamp-self.time>.25:self.trail=[]
            return None
        seed=None
        for row in self.corrections:
            if abs(row['time']-timestamp)<.05 and len(row['entries'].get('ball',[]))==2:seed=np.array(row['entries']['ball'][0])
        gap=timestamp-self.time if self.time is not None else 999
        if gap>.25 and seed is None:self.manual_track=False
        expected=seed if seed is not None else self.last+self.velocity*gap if self.last is not None and gap<.3 else None
        if expected is None and seed is None:
            moving=[]
            if len(self.history)==3 and timestamp-self.history[0][0]<.3:
                for candidate in candidates:
                    point=np.array(candidate['point']);cursor=point;valid=True
                    for past_time,past in reversed(self.history[:-1]):
                        if not past:valid=False;break
                        nearest=min(past,key=lambda p:np.linalg.norm(np.array(p['point'])-cursor))
                        if np.linalg.norm(np.array(nearest['point'])-cursor)>max(30,1800*(timestamp-past_time)):valid=False;break
                        cursor=np.array(nearest['point'])
                    if valid and np.linalg.norm(point-cursor)>=3:moving.append(candidate)
            candidates=moving
        ranked=sorted(candidates,key=lambda c:(np.linalg.norm(np.array(c['point'])-expected) if expected is not None else -c.get('support',c['score'])))
        if expected is not None:
            ranked=[c for c in ranked if np.linalg.norm(np.array(c['point'])-expected)<max(80,1400*min(gap,.3))]
        if not ranked:return None
        if len(ranked)>1 and expected is None and ranked[0]['score']-ranked[1]['score']<.12:return None
        chosen=ranked[0].copy();point=np.array(chosen['point'])
        if seed is not None:self.manual_track=True
        if self.stationary_anchor is None or np.linalg.norm(point-self.stationary_anchor)>4:
            self.stationary_anchor=point;self.stationary_since=timestamp
        elif timestamp-self.stationary_since>.4 and not self.manual_track:
            hands=[np.array(joint[:2]) for person in people for joint in person.get('joints',[])[9:11] if joint[2]>.5]
            if not hands or min(np.linalg.norm(point-hand) for hand in hands)>30:
                self.last=None;self.time=None;self.trail=[];return None
        if self.last is not None and 0<gap<.25:self.velocity=.5*self.velocity+.5*(point-self.last)/gap
        else:self.velocity=np.zeros(2);self.trail=[]
        self.last=point;self.time=timestamp;self.trail.append((timestamp,chosen['point']));self.trail=self.trail[-30:]
        chosen['trail']=[p for t,p in self.trail if timestamp-t<.5];chosen['return_hypothesis']=gap>.25
        return chosen
