"""Explicit, pinned model preparation. Inference never downloads assets."""
import hashlib
import json
from pathlib import Path

import requests

VB_COMMIT='3aad1b98b5b744afb0100418e95892a5b0c23865'
ASSETS={
    'pose':('yolo11m-pose.pt','https://github.com/ultralytics/assets/releases/download/v8.4.0/yolo11m-pose.pt','29b17eaf3a3117cbea906090dbedf9159f7c6a49db58ec8b99ed2dfde1cf6eb2'),
    'ball':('VballNetV4c.onnx',f'https://raw.githubusercontent.com/asigatchov/fast-volleyball-tracking-inference/{VB_COMMIT}/models/VballNetV4c_seq9_grayscale_20260908_213829.onnx','8eea11cc5c881fa008ec55b0f5732ab79f2e0e1833d7f586e680f3aaa98e4b8c'),
}


def prepare(root,progress=lambda text:None,cancel=lambda:False):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((root/'manifest.json').read_text()) if (root/'manifest.json').exists() else {}
    for key,(filename,url,expected) in ASSETS.items():
        path=root/filename
        if key in manifest and manifest[key].get('sha256')==expected and path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==expected:continue
        progress('Подготовка модели: '+key)
        temporary=path.with_suffix(path.suffix+'.partial')
        try:
            with requests.get(url,stream=True,timeout=60) as response:
                response.raise_for_status()
                with temporary.open('wb') as output:
                    for chunk in response.iter_content(1024*1024):
                        if cancel():raise InterruptedError('Подготовка отменена')
                        output.write(chunk)
            if temporary.stat().st_size<1000:raise ValueError('Слишком короткий файл модели')
            digest=hashlib.sha256(temporary.read_bytes()).hexdigest()
            if digest!=expected:raise ValueError('Контрольная сумма модели не совпала: '+key)
            temporary.replace(path)
            manifest[key]={'file':filename,'url':url,'sha256':digest,'third_party_pretrained':True}
            (root/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        finally:
            temporary.unlink(missing_ok=True)
    return manifest


def verified(root,key):
    root=Path(root);manifest=json.loads((root/'manifest.json').read_text()) if (root/'manifest.json').exists() else {}
    info=manifest.get(key)
    if not info:raise ValueError('Сначала нажмите «Подготовить модели»')
    path=root/info['file']
    if path.parent!=root or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=info['sha256']:
        raise ValueError('Модель повреждена: '+key)
    return path
