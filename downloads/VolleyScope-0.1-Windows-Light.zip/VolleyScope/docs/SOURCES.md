# Model and data provenance

This is a new implementation. No source, weights, environment or annotations
from earlier applications were copied.

- Body pose: Ultralytics YOLO11m-pose, COCO-pretrained. Download:
  https://github.com/ultralytics/assets/releases/download/v8.4.0/yolo11m-pose.pt
  SHA256 `29b17eaf3a3117cbea906090dbedf9159f7c6a49db58ec8b99ed2dfde1cf6eb2`.
  Ultralytics package 8.4.184, AGPL-3.0; source accompanies the starter.
- Ball: Alexander Sigatchov, VballNetV4c, sequence 9 grayscale frames,
  https://github.com/asigatchov/fast-volleyball-tracking-inference,
  pinned commit `3aad1b98b5b744afb0100418e95892a5b0c23865`.
  ONNX SHA256 `8eea11cc5c881fa008ec55b0f5732ab79f2e0e1833d7f586e680f3aaa98e4b8c`.
  Upstream repository license MIT. Upstream training-data coverage and rights
  were not independently audited. Runtime adapter is original code.
- Own auxiliary training: two datasets from
  https://github.com/Malgesw/VolleyballObjectDetection, commit
  `d86c9835d84dbaeb218d771af6e44a9f833fcbb5`. Every image/label/config verified
  against its Git blob hash; reproducible inventory in `data_sources/`.
  `dataset_with_test_frames_and_augs` identifies Roboflow
  https://universe.roboflow.com/yolo-e3gpn/volleyball-court-detection-zifgq/dataset/8
  as CC BY 4.0. Attribution is retained here. Ball dataset does not provide a
  separate license declaration; its raw images and failed model are not bundled.
  Broadcast image rights are separate from annotation rights; no raw photographs
  or third-party clips are redistributed in the starter.
- Frozen feature extractor for the auxiliary court head: TorchVision
  MobileNetV3-Small ImageNet weights, freshly downloaded from the official
  PyTorch distribution. TorchVision code BSD-3-Clause; image/weight terms are
  separate. It supplies generic image features, not player ReID identities.
- Integration clip: `examples/gtu_20250316_002.mp4` in Sigatchov's pinned
  repository. Local testing only; not a held-out
  accuracy benchmark, and not included in the package.
- Cyrillic label font: DejaVu Sans from the installed Matplotlib distribution;
  font notices remain in that package. Qt/PySide licensing and notices remain
  in installed wheels. ONNX Runtime MIT, OpenCV Apache-2.0, PyAV BSD.

## VballNet MIT notice

Copyright (c) 2025 Alexander Sigatchov

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
