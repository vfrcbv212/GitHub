"""Fetch the pinned public image/label inventory; verify every Git blob hash."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
from urllib.parse import quote

import requests

ROOT=Path(__file__).resolve().parents[1]


def collect(row,commit):
    relative=Path(row['folder'])/row['path']
    if relative.is_absolute() or '..' in relative.parts:raise ValueError('Invalid dataset path')
    target=ROOT/'datasets'/'external'/relative
    def valid(path):
        if not path.is_file():return False
        raw=path.read_bytes()
        return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_sha']
    if valid(target):return
    url='https://raw.githubusercontent.com/Malgesw/VolleyballObjectDetection/'+commit+'/datasets/'+quote(relative.as_posix(),safe='/')
    for attempt in range(3):
        try:
            response=requests.get(url,timeout=45);response.raise_for_status();raw=response.content
            actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            if actual!=row['git_sha']:raise ValueError('Downloaded data SHA does not match source inventory')
            if raw.startswith(b'version https://git-lfs'):raise ValueError('Source is an LFS pointer, not an image')
            target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_suffix(target.suffix+'.partial')
            temp.write_bytes(raw);temp.replace(target);return
        except (requests.RequestException,ValueError):
            if attempt==2:raise
            time.sleep(attempt+1)


def main():
    inventory=json.loads((ROOT/'data_sources/photo-inventory.json').read_text())
    errors=[];done=0;started=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        pending={pool.submit(collect,row,inventory['commit']):row for row in inventory['files']}
        for future in concurrent.futures.as_completed(pending):
            done+=1
            try:future.result()
            except Exception as exc:errors.append({'path':pending[future]['path'],'error':str(exc)})
            if done%100==0:print(json.dumps({'done':done,'total':len(pending),'errors':len(errors)}),flush=True)
    result={'repository':inventory['repository'],'commit':inventory['commit'],'files':done,
            'elapsed_s':time.monotonic()-started,'errors':errors}
    (ROOT/'work/photo-download-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2));return bool(errors)


if __name__=='__main__':raise SystemExit(main())
