"""Build a small Windows EXE starter with source and prepared model files."""
from pathlib import Path
import argparse
import subprocess
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PYTHON_SHA256='0eb85c2dfccccf1b17352de4c397f69194035b7d37149eacc16f1147d93de3b8'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--light',action='store_true');args=parser.parse_args()
    executable=ROOT/'dist/VolleyScope.exe'
    if not executable.is_file():raise ValueError('Build the fresh C++ launcher first')
    archive=ROOT/('dist/VolleyScope-0.1-Windows-Light.zip' if args.light else 'dist/VolleyScope-0.1-Windows-Starter.zip');entries={};data={}
    try:commit=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,check=True,capture_output=True,text=True).stdout.strip()
    except (OSError,subprocess.CalledProcessError):commit=None
    names=['pyproject.toml','README.md','LICENSE','AGENTS.md','.gitignore']
    for name in names:
        path=ROOT/name
        if path.exists():data[name]=path.read_bytes()
    for folder in ('src','scripts','packaging','tests','docs','data_sources'):
        for path in (ROOT/folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and not any(part.endswith('.egg-info') for part in path.parts):
                data[path.relative_to(ROOT).as_posix()]=path.read_bytes()
    for filename in ('yolo11m-pose.pt','VballNetV4c.onnx','manifest.json'):
        if args.light and filename!='manifest.json':continue
        data['models/'+filename]=(ROOT/'models'/filename).read_bytes()
    for filename in ('court-backbone.pt','court-head-candidate.pt','training.json'):
        data['models/learned/'+filename]=(ROOT/'models/learned'/filename).read_bytes()
    # The failed ball verifier is deliberately absent from the deliverable.
    script=(ROOT/'packaging/Start.ps1').read_text(encoding='utf-8-sig').replace('__PYTHON_SHA256__',PYTHON_SHA256)
    data['Start.ps1']=script.encode('utf-8-sig');data['VolleyScope.exe']=executable.read_bytes()
    data['launch.py']=(ROOT/'packaging/launch.py').read_bytes()
    data['START.txt']=('VolleyScope 0.1 — экспериментальная новая версия.\r\n'
        'Распакуйте весь ZIP и запустите VolleyScope.exe. Первый запуск автоматически\r\n'
        'скачивает Python и библиотеки, включая CUDA для обнаруженной NVIDIA.\r\n'
        'Это может занять несколько гигабайт и требует интернета.\r\n'
        'Видео не отправляются в интернет. Подробности и ограничения: README.md.\r\n'
        'Сборка EXE выполнена; полный запуск этой новой версии на Windows/GPU пока не проверен.\r\n').encode('utf-8-sig')
    for name,raw in data.items():entries[name]=hashlib.sha256(raw).hexdigest()
    manifest={'version':'0.1.0','source_commit':commit,'files':entries,'kind':'automatic-setup starter; not an offline runtime bundle',
              'native_windows_execution_verified':False,'nvidia_execution_verified':False}
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
        for name,raw in sorted(data.items()):output.writestr('VolleyScope/'+name,raw)
        output.writestr('VolleyScope/PACKAGE.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(archive) as check:
        if check.testzip():raise ValueError('Corrupt ZIP')
        for name,sha in entries.items():
            if hashlib.sha256(check.read('VolleyScope/'+name)).hexdigest()!=sha:raise ValueError('Manifest mismatch')
        exe=check.read('VolleyScope/VolleyScope.exe');offset=int.from_bytes(exe[60:64],'little')
        assert exe[:2]==b'MZ' and exe[offset:offset+4]==b'PE\0\0' and int.from_bytes(exe[offset+4:offset+6],'little')==0x8664
    result={'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'files':len(entries),'zip_crc_verified':True,'included_files_sha_manifest_verified':True,
            'pretrained_weights_included':not args.light,'own_court_weights_included':True,
            'real_windows_exe_x64':True,'native_windows_execution_verified':False,'nvidia_verified':False}
    (ROOT/('work/package-light-result.json' if args.light else 'work/package-result.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':main()
