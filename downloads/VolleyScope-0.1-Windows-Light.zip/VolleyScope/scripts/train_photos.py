from pathlib import Path
from volleyscope.learning import train_heads

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    print(train_heads(root/'datasets/external',root/'models/learned',progress=lambda text:print(text,flush=True)))
