﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONNOUSERSITE = '1'
$appRoot = $PSScriptRoot
$python = Join-Path $appRoot 'runtime\python.exe'
$pythonw = Join-Path $appRoot 'runtime\pythonw.exe'
try {
    Set-Location $appRoot
    if (-not (Test-Path $python)) {
        Write-Host 'VolleyScope: подготовка среды. При первом запуске нужен интернет.'
        $temporary = Join-Path $appRoot 'setup-download'
        New-Item -ItemType Directory -Force $temporary | Out-Null
        $archive = Join-Path $temporary 'python.zip'
        Invoke-WebRequest 'https://api.nuget.org/v3-flatcontainer/python/3.12.10/python.3.12.10.nupkg' -OutFile $archive
        if ((Get-FileHash $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '0eb85c2dfccccf1b17352de4c397f69194035b7d37149eacc16f1147d93de3b8') { throw 'Контрольная сумма Python не совпала.' }
        Expand-Archive -Path $archive -DestinationPath (Join-Path $temporary 'unpacked') -Force
        Move-Item (Join-Path $temporary 'unpacked\tools') (Join-Path $appRoot 'runtime')
        Remove-Item $temporary -Recurse -Force
    }
    & $python -m ensurepip --upgrade
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось подготовить pip.' }
    $hasNvidia = $null -ne (Get-Command 'nvidia-smi.exe' -ErrorAction SilentlyContinue)
    $torchIndex = if ($hasNvidia) { 'https://download.pytorch.org/whl/cu126' } else { 'https://download.pytorch.org/whl/cpu' }
    Write-Host 'Подготовка PyTorch. Для NVIDIA загрузка может занимать несколько гигабайт.'
    & $python -m pip install --disable-pip-version-check 'torch==2.13.0' 'torchvision==0.28.0' --index-url $torchIndex
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить PyTorch. Проверьте интернет и свободное место; повторный запуск продолжит подготовку.' }
    & $python -m pip install --disable-pip-version-check $appRoot
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить компоненты программы.' }
    $dllHelper = @'
import importlib.util, pathlib, shutil, sys
spec = importlib.util.find_spec('PySide6')
folder = pathlib.Path(spec.origin).parent
for pattern in ('msvcp140*.dll', 'vcruntime140*.dll', 'concrt140.dll'):
    for source in folder.rglob(pattern):
        target = pathlib.Path(sys.executable).parent / source.name
        if not target.exists():
            shutil.copy2(source, target)
'@
    & $python -c $dllHelper
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось подготовить библиотеки среды Windows.' }
    & $python -c "from volleyscope.assets import prepare; prepare('models',progress=print)"
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось подготовить модели. Повторный запуск продолжит загрузку.' }
    & $python -c "import torch; from PySide6 import QtWidgets; import av,onnxruntime; from volleyscope.assets import verified; verified('models','pose'); verified('models','ball'); print('GPU available:',torch.cuda.is_available())"
    if ($LASTEXITCODE -ne 0) { throw 'Проверка компонентов не прошла.' }
    if ($hasNvidia) {
        & $python -c "import torch; assert torch.cuda.is_available(); print((torch.ones(1,device='cuda')+1).cpu())"
        if ($LASTEXITCODE -ne 0) {
            Write-Host 'GPU не прошла проверку. Программа запустится на CPU; диагностика сохранена.'
        }
    }
    '{"ready":true,"version":"0.1.0"}' | Set-Content (Join-Path $appRoot 'runtime\READY.json') -Encoding UTF8
    Start-Process -FilePath $pythonw -ArgumentList '-I','-B','-X','utf8',('"' + (Join-Path $appRoot 'launch.py') + '"'),'--home',('"' + $appRoot + '"') -WorkingDirectory $appRoot
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    $_ | Out-String | Set-Content (Join-Path $appRoot 'setup-error.txt') -Encoding UTF8
    Read-Host 'Нажмите Enter, чтобы закрыть окно'
    exit 1
}
