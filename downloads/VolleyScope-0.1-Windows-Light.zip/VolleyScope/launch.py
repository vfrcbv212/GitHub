"""Windows entry with a readable error if GUI imports or startup fail."""
from pathlib import Path
import os
import sys
import traceback

root=Path(__file__).resolve().parent
# The shipped, reviewable source wins over an older installed copy when a user
# extracts an update into the same folder. The private runtime supplies libraries.
if (root/'src'/'volleyscope').is_dir():sys.path.insert(0,str(root/'src'))

try:
    from volleyscope.app import main
    raise SystemExit(main())
except Exception:
    (root/'startup-error.txt').write_text(traceback.format_exc(),encoding='utf-8')
    (root/'runtime'/'READY.json').unlink(missing_ok=True)
    if sys.platform=='win32' and os.environ.get('VOLLEYSCOPE_NO_STARTUP_DIALOG')!='1':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,'Не удалось запустить программу. Подробности сохранены в startup-error.txt рядом с EXE.','VolleyScope',0x10)
    raise
